package com.luckynumber.generator;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.text.InputType;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final SecureRandom random = new SecureRandom();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private EditText minField, maxField;
    private TextView result, status;
    private Button generate, history;
    private boolean spinning = false;
    private final List<String> last = new ArrayList<>();
    private SharedPreferences prefs;
    private final int GREEN = Color.rgb(72, 255, 135);
    private final int BACKGROUND = Color.rgb(9, 12, 17);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        prefs = getSharedPreferences("lucky_numbers", MODE_PRIVATE);
        for (int i=0; i<10; i++) {
            String item = prefs.getString("item_"+i, null);
            if (item != null) last.add(item);
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(38), dp(24), dp(28));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);
        TextView title = label("LUCKY NUMBER", 24, Color.WHITE, true);
        root.addView(title);
        TextView subtitle = label("GENERATOR  •  ChatGPT", 13, GREEN, true);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(-1, dp(38));
        root.addView(subtitle, subtitleLp);
        TextView instructions = label("Choose your range", 16, 0xFFACB8C7, false);
        root.addView(instructions);
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.HORIZONTAL);
        fields.setPadding(0, dp(14), 0, dp(16));
        minField = field("MIN", prefs.getString("min", "1"));
        maxField = field("MAX", prefs.getString("max", "100"));
        fields.addView(minField, new LinearLayout.LayoutParams(0, dp(60), 1));
        View spacer = new View(this);
        fields.addView(spacer, new LinearLayout.LayoutParams(dp(12), 1));
        fields.addView(maxField, new LinearLayout.LayoutParams(0, dp(60), 1));
        root.addView(fields, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout display = new LinearLayout(this);
        display.setOrientation(LinearLayout.VERTICAL);
        display.setGravity(Gravity.CENTER);
        display.setBackground(round(0xFF141C21, GREEN, 2, 26));
        result = label("?", 88, GREEN, true);
        result.setSingleLine(true);
        display.addView(result, new LinearLayout.LayoutParams(-1, dp(150)));
        status = label("READY TO GENERATE", 13, 0xFF9DB9A8, false);
        display.addView(status, new LinearLayout.LayoutParams(-1, dp(35)));
        LinearLayout.LayoutParams displayParams = new LinearLayout.LayoutParams(-1, dp(240));
        displayParams.topMargin = dp(10);
        displayParams.bottomMargin = dp(25);
        root.addView(display, displayParams);
        generate = new Button(this);
        generate.setText("GENERATE");
        generate.setTextColor(BACKGROUND);
        generate.setTextSize(20);
        generate.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        generate.setAllCaps(false);
        generate.setBackground(round(GREEN, GREEN, 0, 18));
        root.addView(generate, new LinearLayout.LayoutParams(-1, dp(68)));
        history = new Button(this);
        history.setText("HISTORY  (LAST 10)");
        history.setTextColor(GREEN);
        history.setTextSize(15);
        history.setAllCaps(false);
        history.setBackground(round(0xFF182126, 0xFF3B5D4A, 1, 18));
        LinearLayout.LayoutParams historyLp = new LinearLayout.LayoutParams(-1, dp(58));
        historyLp.topMargin = dp(16);
        root.addView(history, historyLp);
        TextView note = label("SecureRandom  •  Offline  •  Repeats are possible", 12, 0xFF82928C, false);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, dp(58));
        root.addView(note, noteLp);
        setContentView(scroll);
        generate.setOnClickListener(v -> startSpin());
        history.setOnClickListener(v -> showHistory());
    }
    private void startSpin() {
        if (spinning) return;
        final int min, max;
        try {
            min = Integer.parseInt(minField.getText().toString().trim());
            max = Integer.parseInt(maxField.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter valid whole numbers", Toast.LENGTH_LONG).show(); return;
        }
        if (min < 0 || max > 100 || min > max) {
            Toast.makeText(this, "Use a range from 0 to 100 (MIN ≤ MAX)", Toast.LENGTH_LONG).show(); return;
        }
        prefs.edit().putString("min", String.valueOf(min)).putString("max", String.valueOf(max)).apply();
        // One unbiased cryptographically strong draw, made BEFORE the animation.
        final int chosen = min + random.nextInt(max-min+1);
        spinning = true;
        generate.setEnabled(false);
        generate.setAlpha(0.55f);
        minField.setEnabled(false);
        maxField.setEnabled(false);
        status.setText("GENERATING...");
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(minField.getWindowToken(), 0);
        result.clearAnimation();
        long start = android.os.SystemClock.uptimeMillis();
        long duration = 2450;
        Runnable tick = new Runnable() {
            @Override public void run() {
                long elapsed = android.os.SystemClock.uptimeMillis() - start;
                if (elapsed >= duration) {
                    result.setText(String.valueOf(chosen));
                    result.setScaleX(0.88f); result.setScaleY(0.88f); result.setAlpha(0.65f);
                    result.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(280).start();
                    status.setText("YOUR LUCKY NUMBER");
                    last.add(0, min + "–" + max + "  →  " + chosen);
                    if (last.size()>10) last.remove(last.size()-1);
                    SharedPreferences.Editor editor = prefs.edit().clear();
                    editor.putString("min", String.valueOf(min)); editor.putString("max", String.valueOf(max));
                    for (int i=0; i<last.size(); i++) editor.putString("item_"+i,last.get(i));
                    editor.apply();
                    spinning=false; generate.setEnabled(true); generate.setAlpha(1f);
                    minField.setEnabled(true); maxField.setEnabled(true);
                    return;
                }
                result.setText(String.valueOf(min + random.nextInt(max-min+1)));
                double t = (double) elapsed / duration;
                long delay = 35 + (long)(250*t*t*t);
                handler.postDelayed(this, delay);
            }
        };
        handler.post(tick);
    }
    private void showHistory() {
        StringBuilder body = new StringBuilder();
        if (last.isEmpty()) body.append("No results yet.");
        else for (int i=0; i<last.size(); i++) body.append(i+1).append(".  ").append(last.get(i)).append("\n");
        new AlertDialog.Builder(this).setTitle("Last 10 results").setMessage(body.toString())
            .setPositiveButton("CLOSE", (dialog, which) -> dialog.dismiss()).show();
    }
    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setText(value); e.setHint(hint);
        e.setSelectAllOnFocus(true);
        e.setTextColor(Color.WHITE); e.setHintTextColor(0xFF82928C);
        e.setTextSize(22); e.setGravity(Gravity.CENTER);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setBackground(round(0xFF182126, 0xFF3B5D4A, 1, 15));
        return e;
    }
    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(text); v.setTextSize(size);
        v.setTextColor(color); v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private GradientDrawable round(int fill, int stroke, int widthDp, int radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(fill); shape.setCornerRadius(dp(radiusDp));
        if (widthDp>0) shape.setStroke(dp(widthDp), stroke);
        return shape;
    }
    private int dp(int value) { return (int)(getResources().getDisplayMetrics().density*value+0.5f); }
}
